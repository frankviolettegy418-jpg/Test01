package com.onebitmonochrome.blacksbbox.util

import java.util.Locale

object ProfileNameUtil {
    private val facebookCopyPattern = Regex("^(?:fb|facebook)(\\d+)$")

    fun normalize(name: String): String {
        val compactName = name.trim().filterNot { it.isWhitespace() }.lowercase(Locale.ROOT)
        val facebookCopy = facebookCopyPattern.matchEntire(compactName)
        return when {
            facebookCopy != null -> "fb${facebookCopy.groupValues[1]}"
            compactName == "facebook" -> "fb"
            else -> compactName
        }
    }

    fun nextCopyNumber(prefix: String, existingNames: Iterable<String>): Int {
        val normalizedPrefix = normalize(prefix)
        val highestNumber = existingNames
            .asSequence()
            .map(::normalize)
            .mapNotNull { normalizedName ->
                if (!normalizedName.startsWith(normalizedPrefix)) return@mapNotNull null
                normalizedName.removePrefix(normalizedPrefix)
                    .takeIf { suffix -> suffix.isNotEmpty() && suffix.all { it.isDigit() } }
                    ?.toIntOrNull()
            }
            .maxOrNull() ?: 0
        return highestNumber + 1
    }
}
