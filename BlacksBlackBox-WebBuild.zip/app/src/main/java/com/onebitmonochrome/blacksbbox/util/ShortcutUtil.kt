package com.onebitmonochrome.blacksbbox.util

import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import androidx.core.graphics.drawable.toBitmap
import com.afollestad.materialdialogs.MaterialDialog
import com.afollestad.materialdialogs.input.input
import com.onebitmonochrome.blacksbbox.R
import com.onebitmonochrome.blacksbbox.app.App
import com.onebitmonochrome.blacksbbox.app.AppManager
import com.onebitmonochrome.blacksbbox.bean.AppInfo
import com.onebitmonochrome.blacksbbox.util.ContextUtil.openAppSystemSettings
import com.onebitmonochrome.blacksbbox.view.main.ShortcutActivity


object ShortcutUtil {


    
    fun createShortcut(context: Context, userID: Int, info: AppInfo) {

        if (ShortcutManagerCompat.isRequestPinShortcutSupported(context)) {
            val labelName = "${info.name} ${userID + 1}"
            MaterialDialog(context).show {
                title(res = R.string.app_shortcut)
                input(
                    hintRes = R.string.shortcut_name,
                    prefill = labelName
                ) { _, input ->
                    requestPinShortcut(
                        context,
                        userID,
                        info,
                        input.toString().trim().ifEmpty { labelName }
                    )
                    showAllowPermissionDialog(context)
                }
                positiveButton(R.string.done)
                negativeButton(R.string.cancel)
            }

        } else {
            toast(R.string.cannot_create_shortcut)
        }
    }

    fun requestPinShortcut(context: Context, userID: Int, info: AppInfo, label: String): Boolean {
        if (!ShortcutManagerCompat.isRequestPinShortcutSupported(context)) {
            context.toast(R.string.cannot_create_shortcut)
            return false
        }

        val icon = try {
            (info.icon ?: context.packageManager.getApplicationIcon(info.packageName)).toBitmap()
        } catch (e: Exception) {
            Log.e("ShortcutUtil", "Failed to load icon for ${info.packageName}", e)
            context.toast(R.string.cannot_create_shortcut)
            return false
        }
        val intent = Intent(context, ShortcutActivity::class.java)
            .setAction(Intent.ACTION_MAIN)
            .putExtra("pkg", info.packageName)
            .putExtra("userId", userID)
        val safeLabel = label.trim().ifEmpty { "${info.name} ${userID + 1}" }
        val shortcutInfo = ShortcutInfoCompat.Builder(context, "${info.packageName}_$userID")
            .setIntent(intent)
            .setShortLabel(safeLabel)
            .setLongLabel(safeLabel)
            .setIcon(IconCompat.createWithBitmap(icon))
            .build()

        return try {
            ShortcutManagerCompat.requestPinShortcut(context, shortcutInfo, null)
        } catch (e: Exception) {
            Log.e("ShortcutUtil", "Pin request failed for ${info.packageName} userId=$userID", e)
            context.toast(R.string.cannot_create_shortcut)
            false
        }
    }

    private fun showAllowPermissionDialog(context: Context){
        if (!AppManager.mBlackBoxLoader.showShortcutPermissionDialog()){
            return
        }

        MaterialDialog(context).show {
            title(R.string.try_add_shortcut)
            message(R.string.add_shortcut_fail_msg)
            positiveButton(R.string.done)
            negativeButton(R.string.permission_setting){
                App.getContext().openAppSystemSettings()
            }

            neutralButton(R.string.no_reminders){
                AppManager.mBlackBoxLoader.invalidShortcutPermissionDialog(false)
            }
        }

    }
}