package com.onebitmonochrome.blacksbbox.view.main

import android.os.Bundle
import android.text.InputType
import android.util.Log
import android.view.View
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.MaterialAutoCompleteTextView
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.onebitmonochrome.blacksbbox.R
import com.onebitmonochrome.blacksbbox.app.AppManager
import com.onebitmonochrome.blacksbbox.bean.AppInfo
import com.onebitmonochrome.blacksbbox.data.AppsRepository
import com.onebitmonochrome.blacksbbox.util.ShortcutUtil
import com.onebitmonochrome.blacksbbox.util.toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import top.niunaijun.blackbox.BlackBoxCore
import top.niunaijun.blackbox.fake.device.DeviceSpoofManager

class BatchCloneActivity : AppCompatActivity() {
    private data class PinShortcut(val userId: Int, val app: AppInfo, val label: String)

    private lateinit var appInput: MaterialAutoCompleteTextView
    private lateinit var countInput: TextInputEditText
    private lateinit var prefixInput: TextInputEditText
    private lateinit var startButton: MaterialButton
    private lateinit var progressBar: ProgressBar
    private lateinit var statusText: TextView
    private lateinit var pinAllButton: MaterialButton
    private lateinit var pinList: LinearLayout

    private var selectableApps: List<AppInfo> = emptyList()
    private var selectedApp: AppInfo? = null
    private var isCreating = false
    private var isPinningAll = false
    private var readyToPin = emptyList<PinShortcut>()
    private val pinButtons = mutableMapOf<Int, MaterialButton>()
    private val pinRequestsAccepted = mutableSetOf<Int>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(createContentView())
        loadApps()
    }

    private fun createContentView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val toolbar = MaterialToolbar(this).apply {
            title = getString(R.string.batch_clone)
            setNavigationIcon(androidx.appcompat.R.drawable.abc_ic_ab_back_material)
            setNavigationOnClickListener { finish() }
        }
        root.addView(
            toolbar,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(56)
            )
        )

        val scrollView = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val padding = dp(16)
            setPadding(padding, padding, padding, padding)
        }
        appInput = MaterialAutoCompleteTextView(this).apply {
            threshold = 1
            setSingleLine()
        }
        content.addInput(getString(R.string.batch_clone_app), appInput)

        countInput = TextInputEditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText("20")
            setSingleLine()
        }
        content.addInput(getString(R.string.batch_clone_count), countInput)

        prefixInput = TextInputEditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setSingleLine()
        }
        content.addInput(getString(R.string.batch_clone_prefix), prefixInput)

        content.addView(
            TextView(this).apply {
                text = getString(R.string.batch_clone_spoof_info)
            },
            spacedParams()
        )

        startButton = MaterialButton(this).apply {
            text = getString(R.string.batch_clone_start)
            isEnabled = false
            setOnClickListener { startBatch() }
        }
        content.addView(startButton, spacedParams())

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            visibility = View.GONE
        }
        content.addView(progressBar, spacedParams())
        statusText = TextView(this)
        content.addView(statusText, spacedParams())

        pinAllButton = MaterialButton(this).apply {
            text = getString(R.string.batch_clone_pin_all)
            visibility = View.GONE
            isEnabled = false
            setOnClickListener { pinAll() }
        }
        content.addView(pinAllButton, spacedParams())

        pinList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        content.addView(pinList, spacedParams())
        scrollView.addView(content)
        root.addView(
            scrollView,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        )
        return root
    }

    private fun LinearLayout.addInput(label: String, input: View) {
        val inputLayout = TextInputLayout(this@BatchCloneActivity).apply {
            hint = label
            addView(input)
        }
        addView(inputLayout, spacedParams())
    }

    private fun spacedParams(): LinearLayout.LayoutParams {
        return LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            bottomMargin = dp(12)
        }
    }

    private fun loadApps() {
        statusText.text = getString(R.string.batch_clone_loading_apps)
        lifecycleScope.launch {
            try {
                selectableApps = withContext(Dispatchers.IO) {
                    AppsRepository().getSelectableHostApps()
                }
                if (selectableApps.isEmpty()) {
                    statusText.text = getString(R.string.batch_clone_no_apps)
                    return@launch
                }

                val labels = selectableApps.map(::appDisplayName)
                appInput.setAdapter(
                    ArrayAdapter(
                        this@BatchCloneActivity,
                        android.R.layout.simple_dropdown_item_1line,
                        labels
                    )
                )
                appInput.setOnItemClickListener { parent, _, position, _ ->
                    val selectedLabel = parent?.getItemAtPosition(position)?.toString()
                    selectedApp = selectableApps.firstOrNull {
                        appDisplayName(it) == selectedLabel
                    }
                    selectedApp?.let { prefixInput.setText(suggestedPrefix(it)) }
                    startButton.isEnabled = selectedApp != null
                    statusText.text = ""
                }

                val defaultApp = selectableApps.first()
                selectedApp = defaultApp
                appInput.setText(appDisplayName(defaultApp), false)
                prefixInput.setText(suggestedPrefix(defaultApp))
                startButton.isEnabled = true
                statusText.text = ""
            } catch (e: Exception) {
                Log.e(TAG, "Failed to load apps for batch cloning", e)
                statusText.text = e.localizedMessage ?: getString(R.string.batch_clone_no_apps)
            }
        }
    }

    private fun startBatch() {
        if (isCreating) return

        val app = selectedApp
        if (app == null || appInput.text.toString() != appDisplayName(app)) {
            appInput.error = getString(R.string.batch_clone_selection_required)
            return
        }
        val count = countInput.text?.toString()?.toIntOrNull()
        if (count == null || count <= 0) {
            countInput.error = getString(R.string.batch_clone_invalid_count)
            return
        }
        val prefix = prefixInput.text?.toString()?.trim().orEmpty().ifEmpty { app.name }

        isCreating = true
        startButton.isEnabled = false
        progressBar.max = count
        progressBar.progress = 0
        progressBar.visibility = View.VISIBLE
        readyToPin = emptyList()
        pinButtons.clear()
        pinRequestsAccepted.clear()
        pinAllButton.visibility = View.GONE
        pinAllButton.isEnabled = false
        pinList.removeAllViews()

        lifecycleScope.launch {
            val readyToPin = mutableListOf<PinShortcut>()
            val failures = mutableListOf<String>()
            var failedCount = 0
            try {
                withContext(Dispatchers.IO) {
                    val blackBoxCore = BlackBoxCore.get()
                    val existingUserIds = blackBoxCore.users.map { it.id }.toMutableSet()

                    for (userId in 0 until count) {
                        withContext(Dispatchers.Main) {
                            statusText.text = getString(
                                R.string.batch_clone_progress,
                                userId + 1,
                                count,
                                app.name
                            )
                        }
                        try {
                            if (userId !in existingUserIds) {
                                val createdUser = blackBoxCore.createUser(userId)
                                if (createdUser == null) {
                                    failedCount++
                                    failures.add("User $userId: user creation returned no result")
                                    Log.e(TAG, "BlackBox returned no user info for userId=$userId")
                                    continue
                                }
                                existingUserIds.add(userId)
                            }

                            DeviceSpoofManager.ensureRandomProfile(userId)
                            if (!blackBoxCore.isInstalled(app.packageName, userId)) {
                                val result = blackBoxCore.installPackageAsUser(app.packageName, userId)
                                if (!result.success) {
                                    failedCount++
                                    failures.add("User $userId: ${result.msg ?: "installation failed"}")
                                    Log.e(
                                        TAG,
                                        "Failed to install ${app.packageName} for userId=$userId: ${result.msg}"
                                    )
                                    continue
                                }
                            }
                            val preferences = AppManager.mRemarkSharedPreferences
                            val defaultRemark = "User $userId"
                            val currentRemark = preferences.getString("Remark$userId", defaultRemark)
                            if (currentRemark.isNullOrBlank() || currentRemark == defaultRemark) {
                                preferences.edit()
                                    .putString("Remark$userId", "$prefix ${userId + 1}")
                                    .apply()
                            }
                            readyToPin.add(PinShortcut(userId, app, "$prefix ${userId + 1}"))
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            failedCount++
                            failures.add("User $userId: ${e.localizedMessage ?: "operation failed"}")
                            Log.e(TAG, "Failed to create app copy for userId=$userId", e)
                        } finally {
                            withContext(Dispatchers.Main) {
                                progressBar.progress = userId + 1
                            }
                        }
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                failedCount++
                failures.add(e.localizedMessage ?: "Batch operation failed")
                Log.e(TAG, "Batch clone operation failed", e)
            }

            withContext(Dispatchers.Main) {
                isCreating = false
                startButton.isEnabled = true
                this@BatchCloneActivity.readyToPin = readyToPin.toList()
                statusText.text = getString(
                    R.string.batch_clone_complete,
                    readyToPin.size,
                    failedCount
                )
                if (failures.isNotEmpty()) {
                    statusText.append("\n" + failures.take(3).joinToString("\n"))
                }
                if (readyToPin.isNotEmpty()) {
                    pinAllButton.visibility = View.VISIBLE
                    pinList.addView(
                        TextView(this@BatchCloneActivity).apply {
                            text = getString(R.string.batch_clone_pin_title)
                            textSize = 18f
                        },
                        spacedParams()
                    )
                    pinList.addView(
                        TextView(this@BatchCloneActivity).apply {
                            text = getString(R.string.batch_clone_pin_instruction)
                        },
                        spacedParams()
                    )
                }
                readyToPin.forEach(::addPinButton)
                refreshPinAllButton()
                setResult(RESULT_OK)
            }
        }
    }

    private fun addPinButton(shortcut: PinShortcut) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        row.addView(
            TextView(this).apply {
                text = shortcut.label
            },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        )
        val button = MaterialButton(this).apply {
            text = getString(R.string.batch_clone_pin_button, shortcut.label)
            setOnClickListener {
                if (isPinningAll) return@setOnClickListener
                if (ShortcutUtil.requestPinShortcut(
                        this@BatchCloneActivity,
                        shortcut.userId,
                        shortcut.app,
                        shortcut.label
                    )
                ) {
                    pinRequestsAccepted.add(shortcut.userId)
                    text = getString(R.string.batch_clone_pin_sent)
                    refreshPinAllButton()
                }
            }
        }
        pinButtons[shortcut.userId] = button
        row.addView(button)
        pinList.addView(row, spacedParams())
    }

    private fun pinAll() {
        if (isPinningAll) return
        val pending = readyToPin.filter { it.userId !in pinRequestsAccepted }
        if (pending.isEmpty()) return

        isPinningAll = true
        refreshPinAllButton()
        lifecycleScope.launch {
            var requestsSent = 0
            var requestsFailed = 0
            pending.forEachIndexed { index, shortcut ->
                statusText.text = getString(
                    R.string.batch_clone_pin_all_progress,
                    index + 1,
                    pending.size,
                    shortcut.label
                )
                val button = pinButtons[shortcut.userId]
                if (ShortcutUtil.requestPinShortcut(
                        this@BatchCloneActivity,
                        shortcut.userId,
                        shortcut.app,
                        shortcut.label
                    )
                ) {
                    requestsSent++
                    pinRequestsAccepted.add(shortcut.userId)
                    button?.text = getString(R.string.batch_clone_pin_sent)
                } else {
                    requestsFailed++
                }
                if (index < pending.lastIndex) {
                    delay(PIN_REQUEST_DELAY_MS)
                }
            }
            isPinningAll = false
            statusText.text = getString(
                R.string.batch_clone_pin_all_complete,
                requestsSent,
                requestsFailed
            )
            refreshPinAllButton()
        }
    }

    private fun refreshPinAllButton() {
        pinAllButton.isEnabled = !isPinningAll &&
            readyToPin.any { it.userId !in pinRequestsAccepted }
    }

    private fun appDisplayName(app: AppInfo): String = "${app.name} (${app.packageName})"

    private fun suggestedPrefix(app: AppInfo): String {
        return if (app.packageName == FACEBOOK_PACKAGE) "FB" else app.name
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        private const val TAG = "BatchCloneActivity"
        private const val FACEBOOK_PACKAGE = "com.facebook.katana"
        private const val PIN_REQUEST_DELAY_MS = 2500L
    }
}
