package com.onebitmonochrome.blacksbbox.view.main

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity


class ShortcutActivity:AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pkg = intent.getStringExtra("pkg")
        val userID = intent.getIntExtra("userId", -1)

        if (pkg.isNullOrBlank() || userID < 0) {
            Log.e(TAG, "Shortcut missing package or userId: package=$pkg userId=$userID")
            finish()
            return
        }

        try {
            Log.i(TAG, "Forwarding shortcut to BlackBox: package=$pkg userId=$userID")
            val mainIntent = Intent(this, MainActivity::class.java).apply {
                addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_CLEAR_TOP or
                        Intent.FLAG_ACTIVITY_SINGLE_TOP
                )
                putExtra(MainActivity.EXTRA_LAUNCH_PACKAGE, pkg)
                putExtra(MainActivity.EXTRA_LAUNCH_USER_ID, userID)
            }
            startActivity(mainIntent)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to forward shortcut: package=$pkg userId=$userID", e)
        } finally {
            finish()
        }
    }

    companion object {
        private const val TAG = "ShortcutActivity"
    }
}