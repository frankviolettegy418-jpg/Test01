package com.onebitmonochrome.blacksbbox.view.main

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import top.niunaijun.blackbox.BlackBoxCore


class ShortcutActivity:AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pkg = intent.getStringExtra("pkg")
        val userID = intent.getIntExtra("userId", -1)

        lifecycleScope.launch {
            try {
                if (pkg.isNullOrBlank() || userID < 0) {
                    Log.e(TAG, "Shortcut missing package or userId: package=$pkg userId=$userID")
                    return@launch
                }
                Log.i(TAG, "Launching shortcut: package=$pkg userId=$userID")
                val launched = BlackBoxCore.get().launchApk(pkg, userID)
                if (!launched) {
                    Log.e(TAG, "Shortcut launch failed: package=$pkg userId=$userID")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Shortcut launch error: package=$pkg userId=$userID", e)
            } finally {
                finish()
            }
        }
    }

    companion object {
        private const val TAG = "ShortcutActivity"
    }
}