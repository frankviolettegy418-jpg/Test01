package com.onebitmonochrome.blacksbbox.view.main

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.onebitmonochrome.blacksbbox.R
import com.onebitmonochrome.blacksbbox.bean.AppInfo

data class HomeAppEntry(
    val userId: Int,
    val profileName: String,
    val deviceName: String,
    val app: AppInfo,
    val isLocked: Boolean
)

class HomeAppsAdapter(
    private val onClick: (HomeAppEntry) -> Unit,
    private val onLongClick: (View, HomeAppEntry) -> Unit,
    private val onLockClick: (HomeAppEntry) -> Unit
) : RecyclerView.Adapter<HomeAppsAdapter.ViewHolder>() {
    private val entries = mutableListOf<HomeAppEntry>()

    fun submitList(items: List<HomeAppEntry>) {
        entries.clear()
        entries.addAll(items)
        notifyDataSetChanged()
    }

    fun setProfileLocked(userId: Int, locked: Boolean) {
        entries.indices.forEach { index ->
            val entry = entries[index]
            if (entry.userId == userId) {
                entries[index] = entry.copy(isLocked = locked)
            }
        }
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_home_app, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val entry = entries[position]
        holder.icon.setImageDrawable(entry.app.icon)
        holder.name.text = entry.app.name
        holder.profile.text = holder.itemView.context.getString(
            R.string.main_home_app_profile_device,
            entry.profileName,
            entry.deviceName
        )
        holder.lock.setImageResource(
            if (entry.isLocked) R.drawable.ic_lock_24 else R.drawable.ic_lock_open_24
        )
        holder.lock.contentDescription = holder.itemView.context.getString(
            if (entry.isLocked) R.string.unlock_profile else R.string.lock_profile
        )
        holder.lock.setOnClickListener { onLockClick(entry) }
        holder.actions.setOnClickListener { onLongClick(holder.actions, entry) }
        holder.itemView.setOnClickListener { onClick(entry) }
        holder.itemView.setOnLongClickListener {
            onLongClick(holder.itemView, entry)
            true
        }
    }

    override fun getItemCount(): Int = entries.size

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val icon: ImageView = itemView.findViewById(R.id.app_icon)
        val name: TextView = itemView.findViewById(R.id.app_name)
        val profile: TextView = itemView.findViewById(R.id.profile_name)
        val lock: ImageView = itemView.findViewById(R.id.profile_lock)
        val actions: View = itemView.findViewById(R.id.app_actions)
    }
}
