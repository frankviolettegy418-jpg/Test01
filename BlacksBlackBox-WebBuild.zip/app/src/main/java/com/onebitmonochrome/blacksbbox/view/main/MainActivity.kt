package com.onebitmonochrome.blacksbbox.view.main

import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.net.Uri
import android.net.VpnService
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.appcompat.widget.PopupMenu
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.core.content.edit
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.afollestad.materialdialogs.MaterialDialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import top.niunaijun.blackbox.BlackBoxCore
import com.onebitmonochrome.blacksbbox.R
import com.onebitmonochrome.blacksbbox.app.AppFreezeManager
import com.onebitmonochrome.blacksbbox.app.AppManager
import com.onebitmonochrome.blacksbbox.bean.AppInfo
import com.onebitmonochrome.blacksbbox.data.AppsSortComparator
import com.onebitmonochrome.blacksbbox.data.AppsRepository
import com.onebitmonochrome.blacksbbox.databinding.ActivityMainBinding
import com.onebitmonochrome.blacksbbox.util.ShortcutUtil
import com.onebitmonochrome.blacksbbox.util.inflate
import com.onebitmonochrome.blacksbbox.util.toast
import com.onebitmonochrome.blacksbbox.view.base.LoadingActivity
import com.onebitmonochrome.blacksbbox.view.fake.FakeManagerActivity
import com.onebitmonochrome.blacksbbox.view.gallery.BlackBoxGalleryActivity
import com.onebitmonochrome.blacksbbox.view.list.ListActivity
import com.onebitmonochrome.blacksbbox.view.spoof.DeviceSpoofingActivity
import com.onebitmonochrome.blacksbbox.view.setting.SettingActivity
import top.niunaijun.blackbox.core.env.SamsungHealthCompat

class MainActivity : LoadingActivity() {

    private val viewBinding: ActivityMainBinding by inflate()

    private lateinit var homeAppsAdapter: HomeAppsAdapter

    private var currentUser = 0

    companion object {
        private const val TAG = "MainActivity"
        private const val STORAGE_PERMISSION_REQUEST_CODE = 1001
        private const val VPN_PERMISSION_REQUEST_CODE = 1002

        fun start(context: Context) {
            val intent = Intent(context, MainActivity::class.java)
            context.startActivity(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        try {
            super.onCreate(savedInstanceState)

            try {
                BlackBoxCore.get().onBeforeMainActivityOnCreate(this)
            } catch (e: Exception) {
                Log.e(TAG, "Error in onBeforeMainActivityOnCreate: ${e.message}")
            }

            setContentView(viewBinding.root)
            initToolbar(viewBinding.toolbarLayout.toolbar, R.string.app_name)
            initHomeApps()
            initFab()
            initFreezeFab()
            initToolbarSubTitle()

            
            checkStoragePermission()

            
            checkVpnPermission()

            try {
                BlackBoxCore.get().onAfterMainActivityOnCreate(this)
            } catch (e: Exception) {
                Log.e(TAG, "Error in onAfterMainActivityOnCreate: ${e.message}")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Critical error in onCreate: ${e.message}")
            
            showErrorDialog("Failed to initialize app: ${e.message}")
        }
    }

    override fun onResume() {
        super.onResume()
        try {
            updateFreezeFabState()
        } catch (e: Exception) {
            Log.e(TAG, "Error refreshing freeze FAB state: ${e.message}")
        }
    }

    private fun checkStoragePermission() {
        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                
                if (!android.os.Environment.isExternalStorageManager()) {
                    Log.w(TAG, "MANAGE_EXTERNAL_STORAGE permission not granted")
                    showStoragePermissionDialog()
                }
            } else {
                
                if (androidx.core.content.ContextCompat.checkSelfPermission(
                                this,
                                android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                        ) != android.content.pm.PackageManager.PERMISSION_GRANTED ||
                                androidx.core.content.ContextCompat.checkSelfPermission(
                                        this,
                                        android.Manifest.permission.READ_EXTERNAL_STORAGE
                                ) != android.content.pm.PackageManager.PERMISSION_GRANTED
                ) {
                    Log.w(
                            TAG,
                            "Storage permissions not granted on Android ${android.os.Build.VERSION.SDK_INT}"
                    )
                    requestLegacyStoragePermission()
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error checking storage permission: ${e.message}")
        }
    }

    private fun requestLegacyStoragePermission() {
        try {
            androidx.core.app.ActivityCompat.requestPermissions(
                    this,
                    arrayOf(
                            android.Manifest.permission.READ_EXTERNAL_STORAGE,
                            android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                    ),
                    STORAGE_PERMISSION_REQUEST_CODE
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error requesting storage permission: ${e.message}")
        }
    }

    override fun onRequestPermissionsResult(
            requestCode: Int,
            permissions: Array<out String>,
            grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == STORAGE_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() &&
                            grantResults.all {
                                it == android.content.pm.PackageManager.PERMISSION_GRANTED
                            }
            ) {
                Log.d(TAG, "Storage permissions granted")
            } else {
                Log.w(TAG, "Storage permissions denied")
            }
        }
    }

    private fun showStoragePermissionDialog() {
        try {
            MaterialDialog(this).show {
                title(text = "Storage Permission Required")
                message(
                        text =
                                "This app needs 'All Files Access' permission to properly run sandboxed apps. Without this permission, some apps may not work correctly.\n\nPlease grant permission in the next screen."
                )
                positiveButton(text = "Grant Permission") { openAllFilesAccessSettings() }
                negativeButton(text = "Later") { Log.w(TAG, "User postponed storage permission") }
                cancelable(false)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error showing storage permission dialog: ${e.message}")
        }
    }

    private fun openAllFilesAccessSettings() {
        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                val intent =
                        Intent(
                                android.provider.Settings
                                        .ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION
                        )
                intent.data = Uri.parse("package:$packageName")
                storagePermissionResult.launch(intent)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error opening storage settings: ${e.message}")
            
            try {
                val intent =
                        Intent(android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                storagePermissionResult.launch(intent)
            } catch (e2: Exception) {
                Log.e(TAG, "Error opening fallback storage settings: ${e2.message}")
            }
        }
    }

    private val storagePermissionResult =
            registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
                try {
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                        if (android.os.Environment.isExternalStorageManager()) {
                            Log.d(TAG, "Storage permission granted!")
                        } else {
                            Log.w(TAG, "Storage permission still not granted")
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error handling storage permission result: ${e.message}")
                }
            }

    
    private fun checkVpnPermission() {
        try {
            val vpnEnabled = try {
                AppManager.mBlackBoxLoader.useVpnNetwork()
            } catch (e: Exception) {
                Log.e(TAG, "Error reading VPN setting: ${e.message}")
                false
            }

            if (android.os.Build.VERSION.SDK_INT >= 34) {
                if (vpnEnabled) {
                    Log.w(TAG, "VPN setting enabled on SDK>=34; forcing disable (unsupported)")
                    try {
                        AppManager.mBlackBoxLoader.invalidUseVpnNetwork(false)
                    } catch (e: Exception) {
                        Log.e(TAG, "Error disabling VPN setting: ${e.message}")
                    }
                }
                return
            }

            if (!vpnEnabled) {
                Log.d(TAG, "VPN setting disabled; skipping VPN permission")
                return
            }

            val vpnIntent = VpnService.prepare(this)
            if (vpnIntent != null) {
                // Per UX requirement: only prompt for VPN permission when user explicitly
                // enables the toggle in Settings. If permission is missing at startup,
                // disable the toggle and let the user re-enable it to trigger the prompt.
                Log.w(TAG, "VPN setting enabled but permission missing; disabling setting")
                try {
                    AppManager.mBlackBoxLoader.invalidUseVpnNetwork(false)
                } catch (e: Exception) {
                    Log.e(TAG, "Error disabling VPN setting: ${e.message}")
                }
            } else {
                
                Log.d(TAG, "VPN permission already granted")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error checking VPN permission: ${e.message}")
        }
    }

    private val vpnPermissionResult =
            registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
                try {
                    if (result.resultCode == RESULT_OK) {
                        Log.d(TAG, "VPN permission granted!")
                        
                    } else {
                        Log.w(TAG, "VPN permission denied by user")
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error handling VPN permission result: ${e.message}")
                }
            }

    private fun showErrorDialog(message: String) {
        try {
            MaterialDialog(this).show {
                title(text = "Error")
                message(text = message)
                positiveButton(text = "OK") { finish() }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error showing error dialog: ${e.message}")
            finish()
        }
    }

    private fun initToolbarSubTitle() {
        viewBinding.toolbarLayout.toolbar.subtitle = getString(R.string.main_all_clones)
    }

    private fun initHomeApps() {
        homeAppsAdapter = HomeAppsAdapter(
            onClick = { entry ->
                currentUser = entry.userId
                lifecycleScope.launch {
                    val launched = withContext(Dispatchers.IO) {
                        BlackBoxCore.get().launchApk(entry.app.packageName, entry.userId)
                    }
                    if (!launched) toast(R.string.start_fail)
                }
            },
            onLongClick = ::showAppActions
        )
        viewBinding.homeApps.layoutManager = LinearLayoutManager(this)
        viewBinding.homeApps.adapter = homeAppsAdapter
        refreshHomeApps()
    }

    private fun initFab() {
        try {
            viewBinding.fab.setOnClickListener {
                chooseProfile { userId: Int ->
                    currentUser = userId
                    val intent = Intent(this, ListActivity::class.java)
                    intent.putExtra("userID", userId)
                    apkPathResult.launch(intent)
                }
            }
            viewBinding.batchCloneFab.setOnClickListener {
                batchCloneResult.launch(Intent(this, BatchCloneActivity::class.java))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in initFab: ${e.message}")
        }
    }

    private fun initFreezeFab() {
        try {
            updateFreezeFabState()
            viewBinding.freezeFab.setOnClickListener {
                try {
                    if (AppFreezeManager.isGlobalAutoFreezeEnabled()) {
                        AppFreezeManager.setGlobalAutoFreezeEnabled(false)
                        updateFreezeFabState()
                        toast(R.string.auto_freeze_master_disabled)
                    } else {
                        AlertDialog.Builder(this)
                                .setTitle(R.string.auto_freeze_toggle_title)
                                .setMessage(R.string.auto_freeze_toggle_message)
                                .setPositiveButton(R.string.enable) { _, _ ->
                                    AppFreezeManager.setGlobalAutoFreezeEnabled(true)
                                    updateFreezeFabState()
                                    toast(R.string.auto_freeze_master_enabled)
                                }
                                .setNegativeButton(R.string.cancel, null)
                                .show()
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error toggling auto-freeze: ${e.message}")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in initFreezeFab: ${e.message}")
        }
    }

    private fun updateFreezeFabState() {
        val enabled = AppFreezeManager.isGlobalAutoFreezeEnabled()
        viewBinding.freezeFab.setImageResource(
                if (enabled) R.drawable.ic_snowflake else R.drawable.ic_snowflake_off
        )
        viewBinding.freezeFab.imageTintList = null
        viewBinding.freezeFab.backgroundTintList =
                ColorStateList.valueOf(
                        ContextCompat.getColor(
                                this,
                                if (enabled) {
                                    R.color.fab_tint
                                } else {
                                    R.color.surface_variant
                                }
                        )
                )
        viewBinding.freezeFab.contentDescription =
                getString(
                        if (enabled) {
                            R.string.auto_freeze_toggle_on
                        } else {
                            R.string.auto_freeze_toggle_off
                        }
                )
    }

    fun scanUser() {
        refreshHomeApps()
    }

    private fun nextAvailableUserId(existingIds: Set<Int>): Int {
        var candidate = 0
        while (candidate in existingIds) {
            candidate++
        }
        return candidate
    }

    private fun refreshHomeApps() {
        viewBinding.stateView.showLoading()
        lifecycleScope.launch {
            try {
                val entries = withContext(Dispatchers.IO) {
                    val core = BlackBoxCore.get()
                    val rawEntries = core.users.sortedBy { it.id }.flatMap { user ->
                        val defaultName = "User ${user.id}"
                        val profileName = AppManager.mRemarkSharedPreferences
                            .getString("Remark${user.id}", defaultName)
                            ?.takeIf { it.isNotBlank() } ?: defaultName
                        val installedApps = core.getInstalledApplications(0, user.id).orEmpty()
                        val savedOrder = AppManager.mRemarkSharedPreferences
                            .getString("AppList${user.id}", "")
                            .orEmpty()
                            .split(",")
                            .filter { it.isNotBlank() }
                        val orderedApps = if (savedOrder.isEmpty()) installedApps else {
                            installedApps.sortedWith(AppsSortComparator(savedOrder))
                        }
                        orderedApps.mapNotNull { info ->
                            try {
                                val appInfo = AppInfo(
                                    BlackBoxCore.getPackageManager().getApplicationLabel(info).toString(),
                                    BlackBoxCore.getPackageManager().getApplicationIcon(info),
                                    info.packageName,
                                    info.sourceDir ?: "",
                                    false
                                )
                                Triple(user.id, profileName, appInfo)
                            } catch (e: Exception) {
                                Log.w(TAG, "Failed to load app ${info.packageName} for user ${user.id}", e)
                                null
                            }
                        }
                    }
                    val repeatedNames = rawEntries
                        .map { it.first to it.second }
                        .distinct()
                        .groupingBy { it.second }
                        .eachCount()
                    rawEntries.map { (userId, profileName, appInfo) ->
                        HomeAppEntry(
                            userId,
                            if ((repeatedNames[profileName] ?: 0) > 1) {
                                "$profileName (User $userId)"
                            } else {
                                profileName
                            },
                            appInfo
                        )
                    }
                }
                currentUser = BlackBoxCore.get().users.minByOrNull { it.id }?.id ?: 0
                homeAppsAdapter.submitList(entries)
                if (entries.isEmpty()) viewBinding.stateView.showEmpty()
                else viewBinding.stateView.showContent()
            } catch (e: Exception) {
                Log.e(TAG, "Failed to load cloned apps", e)
                viewBinding.stateView.showEmpty()
                toast(e.localizedMessage ?: getString(R.string.main_load_apps_failed))
            }
        }
    }

    private fun chooseProfile(
        includeNewProfile: Boolean = true,
        onSelected: (Int) -> Unit
    ) {
        val users = BlackBoxCore.get().users.sortedBy { it.id }
        val profileIds = users.map { it.id }.toMutableList()
        if (includeNewProfile) profileIds.add(nextAvailableUserId(profileIds.toSet()))
        if (profileIds.isEmpty()) {
            toast(R.string.main_no_profiles)
            return
        }
        val profileLabels = profileIds.map { userId ->
            if (users.any { it.id == userId }) {
                AppManager.mRemarkSharedPreferences.getString("Remark$userId", "User $userId")
                    ?.takeIf { it.isNotBlank() } ?: "User $userId"
            } else {
                getString(R.string.main_new_profile)
            }
        }
        val duplicateLabels = profileLabels.groupingBy { it }.eachCount()
        val labels = profileIds.mapIndexed { index, userId ->
            val label = profileLabels[index]
            if ((duplicateLabels[label] ?: 0) > 1) "$label (User $userId)" else label
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.main_choose_profile)
            .setItems(labels.toTypedArray()) { _, index -> onSelected(profileIds[index]) }
            .show()
    }

    private fun showAppActions(anchor: View, entry: HomeAppEntry) {
        val app = entry.app
        PopupMenu(this, anchor).apply {
            menuInflater.inflate(R.menu.app_menu, menu)
            if (!AppFreezeManager.isGlobalAutoFreezeEnabled()) {
                menu.removeItem(R.id.app_freeze_options)
            }
            if (app.packageName != "com.sec.android.app.shealth") {
                menu.removeItem(R.id.app_shealth_login_fallback)
            } else {
                menu.findItem(R.id.app_shealth_login_fallback)?.setTitle(
                    if (SamsungHealthCompat.isHostSamsungAccountFallbackEnabled(entry.userId, app.packageName)) {
                        R.string.shealth_login_fallback_disable
                    } else {
                        R.string.shealth_login_fallback_enable
                    }
                )
            }
            setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    R.id.app_shortcut ->
                        ShortcutUtil.createShortcut(this@MainActivity, entry.userId, app)
                    R.id.app_stop -> performAppAction(entry, onSuccess = {
                        toast(getString(R.string.is_stop, app.name))
                    }) {
                        BlackBoxCore.get().stopPackage(app.packageName, entry.userId)
                    }
                    R.id.app_clear -> confirmAppAction(
                        entry,
                        R.string.app_clear_hint,
                        action = { BlackBoxCore.get().clearPackage(app.packageName, entry.userId) },
                        onSuccess = {
                            toast(R.string.clear_success)
                            refreshHomeApps()
                        }
                    )
                    R.id.app_remove -> confirmAppAction(
                        entry,
                        R.string.uninstall_app_hint,
                        action = { uninstallClonedApp(entry) },
                        onSuccess = {
                            toast(R.string.uninstall_success)
                            refreshHomeApps()
                        }
                    )
                    R.id.app_freeze_options -> showFreezeOptions(entry)
                    R.id.app_shealth_login_fallback -> toggleSamsungHealthFallback(entry)
                }
                true
            }
            show()
        }
    }

    private fun uninstallClonedApp(entry: HomeAppEntry) {
        val core = BlackBoxCore.get()
        core.uninstallPackageAsUser(entry.app.packageName, entry.userId)

        val preferences = AppManager.mRemarkSharedPreferences
        val sortList = preferences.getString("AppList${entry.userId}", "")
            .orEmpty()
            .split(",")
            .filter { it.isNotBlank() && it != entry.app.packageName }
        preferences.edit {
            putString("AppList${entry.userId}", sortList.joinToString(","))
        }

        var users = core.users
        while (users.isNotEmpty()) {
            val lastUser = users.last()
            if (core.getInstalledApplications(0, lastUser.id).isNotEmpty()) break
            core.deleteUser(lastUser.id)
            preferences.edit {
                remove("Remark${lastUser.id}")
                remove("AppList${lastUser.id}")
            }
            users = core.users
        }
    }

    private fun confirmAppAction(
        entry: HomeAppEntry,
        messageRes: Int,
        action: () -> Unit,
        onSuccess: () -> Unit
    ) {
        val titleRes = if (messageRes == R.string.app_clear_hint) {
            R.string.app_clear
        } else {
            R.string.uninstall_app
        }
        AlertDialog.Builder(this)
            .setTitle(titleRes)
            .setMessage(getString(messageRes, entry.app.name))
            .setPositiveButton(R.string.done) { _, _ ->
                performAppAction(entry, onSuccess = onSuccess, action = action)
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun performAppAction(
        entry: HomeAppEntry,
        onSuccess: () -> Unit = {},
        action: () -> Unit
    ) {
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) { action() }
                onSuccess()
            } catch (e: Exception) {
                Log.e(TAG, "Failed app action for ${entry.app.packageName} in user ${entry.userId}", e)
                toast(e.localizedMessage ?: getString(R.string.start_fail))
            }
        }
    }

    private fun showFreezeOptions(entry: HomeAppEntry) {
        AlertDialog.Builder(this)
            .setTitle(R.string.app_freeze_options)
            .setMessage(getString(R.string.app_freeze_options_hint, entry.app.name))
            .setPositiveButton(android.R.string.yes) { _, _ ->
                AppFreezeManager.setExcludedFromAutoFreeze(entry.app.packageName, entry.userId, true)
                toast(R.string.app_excluded_from_auto_freeze_enabled)
            }
            .setNegativeButton(android.R.string.no) { _, _ ->
                AppFreezeManager.setExcludedFromAutoFreeze(entry.app.packageName, entry.userId, false)
                toast(R.string.app_excluded_from_auto_freeze_disabled)
            }
            .setNeutralButton(R.string.app_freeze_now) { _, _ ->
                performAppAction(entry, onSuccess = {
                    toast(getString(R.string.app_is_frozen, entry.app.name))
                }) {
                    BlackBoxCore.get().stopPackage(entry.app.packageName, entry.userId)
                }
            }
            .show()
    }

    private fun toggleSamsungHealthFallback(entry: HomeAppEntry) {
        val isEnabled = SamsungHealthCompat.isHostSamsungAccountFallbackEnabled(
            entry.userId,
            entry.app.packageName
        )
        if (isEnabled) {
            SamsungHealthCompat.setHostSamsungAccountFallbackEnabled(
                entry.userId,
                entry.app.packageName,
                false
            )
            toast(R.string.shealth_login_fallback_disabled)
        } else {
            AlertDialog.Builder(this)
                .setTitle(R.string.shealth_login_fallback_dialog_title)
                .setMessage(R.string.shealth_login_fallback_dialog_message)
                .setPositiveButton(R.string.enable) { _, _ ->
                    SamsungHealthCompat.setHostSamsungAccountFallbackEnabled(
                        entry.userId,
                        entry.app.packageName,
                        true
                    )
                    toast(R.string.shealth_login_fallback_enabled)
                }
                .setNegativeButton(R.string.cancel, null)
                .show()
        }
    }

    private val apkPathResult =
            registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
                try {
                    if (result.resultCode == RESULT_OK) {
                        result.data?.let { data ->
                            val userId = data.getIntExtra("userID", 0)
                            val source = data.getStringExtra("source")
                            if (source != null) {
                                val resultLiveData = MutableLiveData<String>()
                                val observer = object : Observer<String> {
                                    override fun onChanged(message: String) {
                                        resultLiveData.removeObserver(this)
                                        toast(message)
                                        refreshHomeApps()
                                    }
                                }
                                resultLiveData.observe(this, observer)
                                lifecycleScope.launch {
                                    withContext(Dispatchers.IO) {
                                        AppsRepository().installApk(source, userId, resultLiveData)
                                    }
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error handling APK path result: ${e.message}")
                }
            }

    private val batchCloneResult =
            registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
                if (result.resultCode == RESULT_OK) {
                    scanUser()
                }
            }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        try {
            menuInflater.inflate(R.menu.menu_main, menu)
            return true
        } catch (e: Exception) {
            Log.e(TAG, "Error creating options menu: ${e.message}")
            return false
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        try {
            when (item.itemId) {
                R.id.main_setting -> {
                    SettingActivity.start(this)
                }
                R.id.fake_location -> {
                    chooseProfile(onSelected = { userId ->
                        currentUser = userId
                        val intent = Intent(this, FakeManagerActivity::class.java)
                        intent.putExtra("userID", userId)
                        startActivity(intent)
                    }, includeNewProfile = false)
                }
                R.id.device_spoofing -> {
                    chooseProfile(onSelected = { userId ->
                        currentUser = userId
                        DeviceSpoofingActivity.start(this, userId)
                    }, includeNewProfile = false)
                }
                R.id.blackbox_gallery -> {
                    chooseProfile(onSelected = { userId ->
                        currentUser = userId
                        BlackBoxGalleryActivity.start(this, userId)
                    }, includeNewProfile = false)
                }
            }

            return true
        } catch (e: Exception) {
            Log.e(TAG, "Error handling menu item selection: ${e.message}")
            return false
        }
    }
}
