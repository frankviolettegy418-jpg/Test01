package com.onebitmonochrome.blacksbbox.view.main

import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.net.Uri
import android.net.VpnService
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.core.content.edit
import androidx.viewpager2.widget.ViewPager2
import com.afollestad.materialdialogs.MaterialDialog
import com.afollestad.materialdialogs.input.input
import top.niunaijun.blackbox.BlackBoxCore
import com.onebitmonochrome.blacksbbox.R
import com.onebitmonochrome.blacksbbox.app.App
import com.onebitmonochrome.blacksbbox.app.AppFreezeManager
import com.onebitmonochrome.blacksbbox.app.AppManager
import com.onebitmonochrome.blacksbbox.databinding.ActivityMainBinding
import com.onebitmonochrome.blacksbbox.util.Resolution
import com.onebitmonochrome.blacksbbox.util.inflate
import com.onebitmonochrome.blacksbbox.util.toast
import com.onebitmonochrome.blacksbbox.view.apps.AppsFragment
import com.onebitmonochrome.blacksbbox.view.base.LoadingActivity
import com.onebitmonochrome.blacksbbox.view.fake.FakeManagerActivity
import com.onebitmonochrome.blacksbbox.view.gallery.BlackBoxGalleryActivity
import com.onebitmonochrome.blacksbbox.view.list.ListActivity
import com.onebitmonochrome.blacksbbox.view.spoof.DeviceSpoofingActivity
import com.onebitmonochrome.blacksbbox.view.setting.SettingActivity

class MainActivity : LoadingActivity() {

    private val viewBinding: ActivityMainBinding by inflate()

    private lateinit var mViewPagerAdapter: ViewPagerAdapter

    private val fragmentList = mutableListOf<AppsFragment>()

    private var currentUser = 0

    companion object {
        private const val TAG = "MainActivity"
        private const val STORAGE_PERMISSION_REQUEST_CODE = 1001
        private const val VPN_PERMISSION_REQUEST_CODE = 1002

        fun start(context: Context) {
            val intent = Intent(context, MainActivity::class.java)
            context.startActivity(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        try {
            super.onCreate(savedInstanceState)

            try {
                BlackBoxCore.get().onBeforeMainActivityOnCreate(this)
            } catch (e: Exception) {
                Log.e(TAG, "Error in onBeforeMainActivityOnCreate: ${e.message}")
            }

            setContentView(viewBinding.root)
            initToolbar(viewBinding.toolbarLayout.toolbar, R.string.app_name)
            initViewPager()
            initFab()
            initFreezeFab()
            initToolbarSubTitle()

            
            checkStoragePermission()

            
            checkVpnPermission()

            try {
                BlackBoxCore.get().onAfterMainActivityOnCreate(this)
            } catch (e: Exception) {
                Log.e(TAG, "Error in onAfterMainActivityOnCreate: ${e.message}")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Critical error in onCreate: ${e.message}")
            
            showErrorDialog("Failed to initialize app: ${e.message}")
        }
    }

    override fun onResume() {
        super.onResume()
        try {
            updateFreezeFabState()
        } catch (e: Exception) {
            Log.e(TAG, "Error refreshing freeze FAB state: ${e.message}")
        }
    }

    private fun checkStoragePermission() {
        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                
                if (!android.os.Environment.isExternalStorageManager()) {
                    Log.w(TAG, "MANAGE_EXTERNAL_STORAGE permission not granted")
                    showStoragePermissionDialog()
                }
            } else {
                
                if (androidx.core.content.ContextCompat.checkSelfPermission(
                                this,
                                android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                        ) != android.content.pm.PackageManager.PERMISSION_GRANTED ||
                                androidx.core.content.ContextCompat.checkSelfPermission(
                                        this,
                                        android.Manifest.permission.READ_EXTERNAL_STORAGE
                                ) != android.content.pm.PackageManager.PERMISSION_GRANTED
                ) {
                    Log.w(
                            TAG,
                            "Storage permissions not granted on Android ${android.os.Build.VERSION.SDK_INT}"
                    )
                    requestLegacyStoragePermission()
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error checking storage permission: ${e.message}")
        }
    }

    private fun requestLegacyStoragePermission() {
        try {
            androidx.core.app.ActivityCompat.requestPermissions(
                    this,
                    arrayOf(
                            android.Manifest.permission.READ_EXTERNAL_STORAGE,
                            android.Manifest.permission.WRITE_EXTERNAL_STORAGE
                    ),
                    STORAGE_PERMISSION_REQUEST_CODE
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error requesting storage permission: ${e.message}")
        }
    }

    override fun onRequestPermissionsResult(
            requestCode: Int,
            permissions: Array<out String>,
            grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == STORAGE_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() &&
                            grantResults.all {
                                it == android.content.pm.PackageManager.PERMISSION_GRANTED
                            }
            ) {
                Log.d(TAG, "Storage permissions granted")
            } else {
                Log.w(TAG, "Storage permissions denied")
            }
        }
    }

    private fun showStoragePermissionDialog() {
        try {
            MaterialDialog(this).show {
                title(text = "Storage Permission Required")
                message(
                        text =
                                "This app needs 'All Files Access' permission to properly run sandboxed apps. Without this permission, some apps may not work correctly.\n\nPlease grant permission in the next screen."
                )
                positiveButton(text = "Grant Permission") { openAllFilesAccessSettings() }
                negativeButton(text = "Later") { Log.w(TAG, "User postponed storage permission") }
                cancelable(false)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error showing storage permission dialog: ${e.message}")
        }
    }

    private fun openAllFilesAccessSettings() {
        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                val intent =
                        Intent(
                                android.provider.Settings
                                        .ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION
                        )
                intent.data = Uri.parse("package:$packageName")
                storagePermissionResult.launch(intent)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error opening storage settings: ${e.message}")
            
            try {
                val intent =
                        Intent(android.provider.Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                storagePermissionResult.launch(intent)
            } catch (e2: Exception) {
                Log.e(TAG, "Error opening fallback storage settings: ${e2.message}")
            }
        }
    }

    private val storagePermissionResult =
            registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
                try {
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                        if (android.os.Environment.isExternalStorageManager()) {
                            Log.d(TAG, "Storage permission granted!")
                        } else {
                            Log.w(TAG, "Storage permission still not granted")
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error handling storage permission result: ${e.message}")
                }
            }

    
    private fun checkVpnPermission() {
        try {
            val vpnEnabled = try {
                AppManager.mBlackBoxLoader.useVpnNetwork()
            } catch (e: Exception) {
                Log.e(TAG, "Error reading VPN setting: ${e.message}")
                false
            }

            if (android.os.Build.VERSION.SDK_INT >= 34) {
                if (vpnEnabled) {
                    Log.w(TAG, "VPN setting enabled on SDK>=34; forcing disable (unsupported)")
                    try {
                        AppManager.mBlackBoxLoader.invalidUseVpnNetwork(false)
                    } catch (e: Exception) {
                        Log.e(TAG, "Error disabling VPN setting: ${e.message}")
                    }
                }
                return
            }

            if (!vpnEnabled) {
                Log.d(TAG, "VPN setting disabled; skipping VPN permission")
                return
            }

            val vpnIntent = VpnService.prepare(this)
            if (vpnIntent != null) {
                // Per UX requirement: only prompt for VPN permission when user explicitly
                // enables the toggle in Settings. If permission is missing at startup,
                // disable the toggle and let the user re-enable it to trigger the prompt.
                Log.w(TAG, "VPN setting enabled but permission missing; disabling setting")
                try {
                    AppManager.mBlackBoxLoader.invalidUseVpnNetwork(false)
                } catch (e: Exception) {
                    Log.e(TAG, "Error disabling VPN setting: ${e.message}")
                }
            } else {
                
                Log.d(TAG, "VPN permission already granted")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error checking VPN permission: ${e.message}")
        }
    }

    private val vpnPermissionResult =
            registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
                try {
                    if (result.resultCode == RESULT_OK) {
                        Log.d(TAG, "VPN permission granted!")
                        
                    } else {
                        Log.w(TAG, "VPN permission denied by user")
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error handling VPN permission result: ${e.message}")
                }
            }

    private fun showErrorDialog(message: String) {
        try {
            MaterialDialog(this).show {
                title(text = "Error")
                message(text = message)
                positiveButton(text = "OK") { finish() }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error showing error dialog: ${e.message}")
            finish()
        }
    }

    private fun initToolbarSubTitle() {
        try {
            updateUserRemark(currentUser)
            
            viewBinding.toolbarLayout.toolbar.getChildAt(1)?.setOnClickListener {
                try {
                    MaterialDialog(this).show {
                        title(res = R.string.userRemark)
                        input(
                                hintRes = R.string.userRemark,
                                prefill = viewBinding.toolbarLayout.toolbar.subtitle
                        ) { _, input ->
                            try {
                                AppManager.mRemarkSharedPreferences.edit {
                                    putString("Remark$currentUser", input.toString())
                                    viewBinding.toolbarLayout.toolbar.subtitle = input
                                }
                            } catch (e: Exception) {
                                Log.e(TAG, "Error saving user remark: ${e.message}")
                            }
                        }
                        positiveButton(res = R.string.done)
                        negativeButton(res = R.string.cancel)
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error showing remark dialog: ${e.message}")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in initToolbarSubTitle: ${e.message}")
        }
    }

    private fun initViewPager() {
        try {
            val userList = BlackBoxCore.get().users.sortedBy { it.id }
            userList.forEach { fragmentList.add(AppsFragment.newInstance(it.id)) }

            currentUser = userList.firstOrNull()?.id ?: 0
            fragmentList.add(AppsFragment.newInstance(nextAvailableUserId(userList.map { it.id }.toSet())))

            mViewPagerAdapter = ViewPagerAdapter(this)
            mViewPagerAdapter.replaceData(fragmentList)
            viewBinding.viewPager.adapter = mViewPagerAdapter
            viewBinding.viewPager.offscreenPageLimit = 1
            viewBinding.viewPager.setPageTransformer { page, position ->
                val absPos = kotlin.math.abs(position)
                val scale = 0.94f + ((1f - absPos.coerceAtMost(1f)) * 0.06f)
                page.scaleX = scale
                page.scaleY = scale
                page.alpha = 0.75f + ((1f - absPos.coerceAtMost(1f)) * 0.25f)
                page.translationX = -position * 22f
            }
            viewBinding.dotsIndicator.setViewPager2(viewBinding.viewPager)
            viewBinding.viewPager.registerOnPageChangeCallback(
                    object : ViewPager2.OnPageChangeCallback() {
                        override fun onPageSelected(position: Int) {
                            try {
                                super.onPageSelected(position)
                                currentUser = if (position in userList.indices) {
                                    userList[position].id
                                } else {
                                    fragmentList[position].userID
                                }
                                updateUserRemark(currentUser)
                                showFloatButton(true)
                            } catch (e: Exception) {
                                Log.e(TAG, "Error in onPageSelected: ${e.message}")
                            }
                        }
                    }
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error in initViewPager: ${e.message}")
        }
    }

    private fun initFab() {
        try {
            viewBinding.fab.setOnClickListener {
                try {
                    val userId = currentUser
                    val intent = Intent(this, ListActivity::class.java)
                    intent.putExtra("userID", userId)
                    apkPathResult.launch(intent)
                } catch (e: Exception) {
                    Log.e(TAG, "Error launching ListActivity: ${e.message}")
                }
            }
            viewBinding.batchCloneFab.setOnClickListener {
                batchCloneResult.launch(Intent(this, BatchCloneActivity::class.java))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in initFab: ${e.message}")
        }
    }

    private fun initFreezeFab() {
        try {
            updateFreezeFabState()
            viewBinding.freezeFab.setOnClickListener {
                try {
                    if (AppFreezeManager.isGlobalAutoFreezeEnabled()) {
                        AppFreezeManager.setGlobalAutoFreezeEnabled(false)
                        updateFreezeFabState()
                        toast(R.string.auto_freeze_master_disabled)
                    } else {
                        AlertDialog.Builder(this)
                                .setTitle(R.string.auto_freeze_toggle_title)
                                .setMessage(R.string.auto_freeze_toggle_message)
                                .setPositiveButton(R.string.enable) { _, _ ->
                                    AppFreezeManager.setGlobalAutoFreezeEnabled(true)
                                    updateFreezeFabState()
                                    toast(R.string.auto_freeze_master_enabled)
                                }
                                .setNegativeButton(R.string.cancel, null)
                                .show()
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error toggling auto-freeze: ${e.message}")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in initFreezeFab: ${e.message}")
        }
    }

    private fun updateFreezeFabState() {
        val enabled = AppFreezeManager.isGlobalAutoFreezeEnabled()
        viewBinding.freezeFab.setImageResource(
                if (enabled) R.drawable.ic_snowflake else R.drawable.ic_snowflake_off
        )
        viewBinding.freezeFab.imageTintList = null
        viewBinding.freezeFab.backgroundTintList =
                ColorStateList.valueOf(
                        ContextCompat.getColor(
                                this,
                                if (enabled) {
                                    R.color.fab_tint
                                } else {
                                    R.color.surface_variant
                                }
                        )
                )
        viewBinding.freezeFab.contentDescription =
                getString(
                        if (enabled) {
                            R.string.auto_freeze_toggle_on
                        } else {
                            R.string.auto_freeze_toggle_off
                        }
                )
    }

    fun showFloatButton(show: Boolean) {
        try {
            val tranY: Float = Resolution.convertDpToPixel(120F, App.getContext())
            val time = 200L
            if (show) {
                viewBinding.fab.animate().translationY(0f).alpha(1f).setDuration(time).start()
                viewBinding.freezeFab
                        .animate()
                        .translationY(0f)
                        .alpha(1f)
                        .setDuration(time)
                        .start()
            } else {
                viewBinding.fab.animate().translationY(tranY).alpha(0f).setDuration(time).start()
                viewBinding.freezeFab
                        .animate()
                        .translationY(tranY)
                        .alpha(0f)
                        .setDuration(time)
                        .start()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in showFloatButton: ${e.message}")
        }
    }

    fun scanUser() {
        try {
            val userList = BlackBoxCore.get().users.sortedBy { it.id }
            val currentId = currentUser
            val existingFragments = fragmentList.associateBy { it.userID }
            val userIds = userList.map { it.id }
            val pageIds = userIds + nextAvailableUserId(userIds.toSet())
            val updatedFragments = pageIds.map { userId ->
                existingFragments[userId] ?: AppsFragment.newInstance(userId)
            }.toMutableList()

            fragmentList.clear()
            fragmentList.addAll(updatedFragments)
            mViewPagerAdapter.replaceData(fragmentList)
            val currentPage = fragmentList.indexOfFirst { it.userID == currentId }
            if (currentPage >= 0) {
                viewBinding.viewPager.setCurrentItem(currentPage, false)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in scanUser: ${e.message}")
        }
    }

    private fun nextAvailableUserId(existingIds: Set<Int>): Int {
        var candidate = 0
        while (candidate in existingIds) {
            candidate++
        }
        return candidate
    }

    private fun updateUserRemark(userId: Int) {
        try {
            var remark =
                    AppManager.mRemarkSharedPreferences.getString("Remark$userId", "User $userId")
            if (remark.isNullOrEmpty()) {
                remark = "User $userId"
            }

            viewBinding.toolbarLayout.toolbar.subtitle = remark
        } catch (e: Exception) {
            Log.e(TAG, "Error updating user remark: ${e.message}")
            viewBinding.toolbarLayout.toolbar.subtitle = "User $userId"
        }
    }

    private val apkPathResult =
            registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
                try {
                    if (it.resultCode == RESULT_OK) {
                        it.data?.let { data ->
                            val userId = data.getIntExtra("userID", 0)
                            val source = data.getStringExtra("source")
                            if (source != null) {
                                val targetFragment = fragmentList.firstOrNull { f -> f.userID == userId }
                                if (targetFragment != null) {
                                    targetFragment.installApk(source)
                                } else {
                                    Log.w(TAG, "No fragment found for userId=$userId; dropping install result")
                                }

    private val batchCloneResult =
                                registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
                                    if (it.resultCode == RESULT_OK) {
                                        scanUser()
                                    }
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error handling APK path result: ${e.message}")
                }
            }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        try {
            menuInflater.inflate(R.menu.menu_main, menu)
            return true
        } catch (e: Exception) {
            Log.e(TAG, "Error creating options menu: ${e.message}")
            return false
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        try {
            when (item.itemId) {
                R.id.main_setting -> {
                    SettingActivity.start(this)
                }
                R.id.fake_location -> {
                    
                    val intent = Intent(this, FakeManagerActivity::class.java)
                    intent.putExtra("userID", currentUser)
                    startActivity(intent)
                }
                R.id.device_spoofing -> {
                    DeviceSpoofingActivity.start(this, currentUser)
                }
                R.id.blackbox_gallery -> {
                    BlackBoxGalleryActivity.start(this, currentUser)
                }
            }

            return true
        } catch (e: Exception) {
            Log.e(TAG, "Error handling menu item selection: ${e.message}")
            return false
        }
    }
}
