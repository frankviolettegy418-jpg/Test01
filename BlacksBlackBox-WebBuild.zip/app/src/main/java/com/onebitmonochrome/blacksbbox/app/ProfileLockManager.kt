package com.onebitmonochrome.blacksbbox.app

import top.niunaijun.blackbox.BlackBoxCore

object ProfileLockManager {
    private const val LOCKED_KEY_PREFIX = "ProfileLocked"

    fun isLocked(userId: Int): Boolean {
        return AppManager.mRemarkSharedPreferences.getBoolean("$LOCKED_KEY_PREFIX$userId", false)
    }

    fun setLocked(userId: Int, locked: Boolean) {
        AppManager.mRemarkSharedPreferences.edit()
            .putBoolean("$LOCKED_KEY_PREFIX$userId", locked)
            .apply()
    }

    fun deleteIfEmpty(userId: Int): Boolean {
        if (isLocked(userId)) return false

        val core = BlackBoxCore.get()
        if (core.users.none { it.id == userId }) return false
        if (core.getInstalledApplications(0, userId).isNotEmpty()) return false

        core.deleteUser(userId)
        AppManager.mRemarkSharedPreferences.edit().apply {
            remove("Remark$userId")
            remove("AppList$userId")
            remove("$LOCKED_KEY_PREFIX$userId")
            apply()
        }
        return true
    }

    fun cleanupLastEmptyProfiles() {
        while (true) {
            val lastUser = BlackBoxCore.get().users.maxByOrNull { it.id } ?: return
            if (!deleteIfEmpty(lastUser.id)) return
        }
    }
}
