package com.onebitmonochrome.blacksbbox.util

import org.junit.Assert.assertEquals
import org.junit.Test

class ProfileNameUtilTest {
    @Test
    fun nextCopyNumberContinuesAfterExistingFacebookProfiles() {
        val existingNames = (1..5).map { "FB $it" } + "Facebook 1"

        assertEquals(6, ProfileNameUtil.nextCopyNumber("FB", existingNames))
    }

    @Test
    fun normalizeTreatsFacebookAliasesAndSpacingAsSameName() {
        assertEquals(ProfileNameUtil.normalize("FB 1"), ProfileNameUtil.normalize("facebook1"))
        assertEquals(listOf("fb1"), listOf("FB 1").map(ProfileNameUtil::normalize))
    }
}
