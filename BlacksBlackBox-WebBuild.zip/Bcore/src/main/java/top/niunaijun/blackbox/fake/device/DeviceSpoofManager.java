package top.niunaijun.blackbox.fake.device;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.app.BActivityThread;
import top.niunaijun.blackbox.core.NativeCore;
import top.niunaijun.blackbox.core.system.user.BUserInfo;
import top.niunaijun.blackbox.utils.Md5Utils;
import top.niunaijun.blackbox.utils.Slog;

public final class DeviceSpoofManager {
    private static final String TAG = "DeviceSpoofManager";
    private static final String PREFS_NAME = "DeviceSpoofProfiles";

    private static final String KEY_MANUFACTURER = "manufacturer_";
    private static final String KEY_MODEL = "model_";
    private static final String KEY_BRAND = "brand_";
    private static final String KEY_DEVICE = "device_";
    private static final String KEY_PRODUCT = "product_";
    private static final String KEY_BOARD = "board_";
    private static final String KEY_FINGERPRINT = "fingerprint_";
    private static final String KEY_SERIAL = "serial_";
    private static final String KEY_ANDROID_ID = "android_id_";
    private static final SecureRandom RANDOM = new SecureRandom();

    private static final DevicePreset[] PRESETS = {
            new DevicePreset("Samsung", "samsung", "Galaxy S22", "r0s", "r0s", "lahaina", "14", "UP1A.231005.007", "S901BXXS"),
            new DevicePreset("Samsung", "samsung", "Galaxy S22+", "g0s", "g0s", "taro", "14", "UP1A.231005.007", "S906BXXS"),
            new DevicePreset("Samsung", "samsung", "Galaxy S22 Ultra", "b0s", "b0s", "taro", "14", "UP1A.231005.007", "S908BXXS"),
            new DevicePreset("Samsung", "samsung", "Galaxy S23", "dm1q", "dm1q", "kalama", "15", "AP3A.241005.015", "S911BXXS"),
            new DevicePreset("Samsung", "samsung", "Galaxy S23+", "dm2q", "dm2q", "kalama", "15", "AP3A.241005.015", "S916BXXS"),
            new DevicePreset("Samsung", "samsung", "Galaxy S23 Ultra", "dm3q", "dm3q", "kalama", "15", "AP3A.241005.015", "S918BXXS"),
            new DevicePreset("Samsung", "samsung", "Galaxy A54", "a54x", "a54x", "s5e8835", "14", "UP1A.231005.007", "A546BXXS"),
            new DevicePreset("Samsung", "samsung", "Galaxy A34", "a34x", "a34x", "s5e8825", "14", "UP1A.231005.007", "A346BXXS"),
            new DevicePreset("Xiaomi", "xiaomi", "Xiaomi 12", "cupid", "cupid", "taro", "14", "UKQ1.230804.001", "V14.0.8.0"),
            new DevicePreset("Xiaomi", "xiaomi", "Xiaomi 12 Pro", "zeus", "zeus", "taro", "14", "UKQ1.230804.001", "V14.0.8.0"),
            new DevicePreset("Xiaomi", "xiaomi", "Xiaomi 13", "fuxi", "fuxi", "kalama", "14", "UKQ1.230804.001", "V14.0.8.0"),
            new DevicePreset("Xiaomi", "xiaomi", "Xiaomi 13 Pro", "nuwa", "nuwa", "kalama", "14", "UKQ1.230804.001", "V14.0.8.0"),
            new DevicePreset("Xiaomi", "xiaomi", "Xiaomi 13T", "aristotle", "aristotle", "mt6896", "14", "UKQ1.230804.001", "V14.0.8.0"),
            new DevicePreset("Redmi", "redmi", "Redmi Note 12", "tapas", "tapas", "sm6225", "14", "UKQ1.230804.001", "V14.0.8.0"),
            new DevicePreset("Redmi", "redmi", "Redmi Note 12 Pro", "ruby", "ruby", "mt6877", "14", "UKQ1.230804.001", "V14.0.8.0"),
            new DevicePreset("Redmi", "redmi", "Redmi Note 13", "sapphire", "sapphire", "sm6225", "14", "UKQ1.230804.001", "V14.0.8.0"),
            new DevicePreset("Redmi", "redmi", "Redmi Note 13 Pro", "garnet", "garnet", "sm7435", "14", "UKQ1.230804.001", "V14.0.8.0"),
            new DevicePreset("OPPO", "oppo", "Reno8", "reno8", "reno8", "mt6895", "14", "UKQ1.230804.001", "CPH2359_14"),
            new DevicePreset("OPPO", "oppo", "Reno8 Pro", "reno8pro", "reno8pro", "mt6895", "14", "UKQ1.230804.001", "CPH2357_14"),
            new DevicePreset("OPPO", "oppo", "Reno9", "reno9", "reno9", "sm7325", "14", "UKQ1.230804.001", "CPH2523_14"),
            new DevicePreset("OPPO", "oppo", "Reno9 Pro", "reno9pro", "reno9pro", "mt6895", "14", "UKQ1.230804.001", "CPH2525_14"),
            new DevicePreset("Google", "google", "Pixel 7", "panther", "panther", "gs201", "14", "UP1A.231005.007", "11010323"),
            new DevicePreset("Google", "google", "Pixel 7 Pro", "cheetah", "cheetah", "gs201", "14", "UP1A.231005.007", "11010323"),
            new DevicePreset("Google", "google", "Pixel 8", "shiba", "shiba", "zumapro", "15", "AP3A.241005.015", "12366786"),
            new DevicePreset("Google", "google", "Pixel 8 Pro", "husky", "husky", "zumapro", "15", "AP3A.241005.015", "12366786")
    };

    private DeviceSpoofManager() {
    }

    @SuppressWarnings("deprecation")
    private static SharedPreferences prefs() {
        return BlackBoxCore.getContext()
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE | Context.MODE_MULTI_PROCESS);
    }

    public static DeviceSpoofProfile getProfile(int userId) {
        DeviceSpoofProfile defaults = getDefaultProfile(userId);
        SharedPreferences prefs = prefs();
        return new DeviceSpoofProfile(
                valueOrDefault(prefs.getString(KEY_MANUFACTURER + userId, null), defaults.manufacturer),
                valueOrDefault(prefs.getString(KEY_BRAND + userId, null), defaults.brand),
                valueOrDefault(prefs.getString(KEY_MODEL + userId, null), defaults.model),
                valueOrDefault(prefs.getString(KEY_DEVICE + userId, null), defaults.device),
                valueOrDefault(prefs.getString(KEY_PRODUCT + userId, null), defaults.product),
                valueOrDefault(prefs.getString(KEY_BOARD + userId, null), defaults.board),
                valueOrDefault(prefs.getString(KEY_FINGERPRINT + userId, null), defaults.fingerprint),
                valueOrDefault(prefs.getString(KEY_SERIAL + userId, null), defaults.serial),
                valueOrDefault(prefs.getString(KEY_ANDROID_ID + userId, null), defaults.androidId)
        );
    }

    public static DeviceSpoofProfile getDefaultProfile(int userId) {
        return new DeviceSpoofProfile(
                "Google",
                "google",
                "Pixel 6",
                "oriole",
                "oriole",
                "oriole",
                "google/oriole/oriole:12/SP1A.210812.015/7679548:user/release-keys",
                "1A2B3C4D5E6F",
                stableAndroidId("bbb_default_" + userId)
        );
    }

    public static DeviceSpoofProfile getSamsungPreset(int userId) {
        return new DeviceSpoofProfile(
                "Samsung",
                "samsung",
                "Galaxy S26+",
                "s26plus",
                "s26plus",
                "kalama",
                "samsung/s26plus/s26plus:16/BBX1.260329.001/S26PLUS:user/release-keys",
                "S26PBBX260329",
                stableAndroidId("bbb_samsung_" + userId)
        );
    }

    public static void saveUserProfile(int userId, String manufacturer, String model, String androidId) {
        DeviceSpoofProfile profile = buildCustomProfile(userId, manufacturer, model, androidId);
        saveProfile(userId, profile);
    }

    public static synchronized DeviceSpoofProfile ensureRandomProfile(int userId) {
        SharedPreferences preferences = prefs();
        if (preferences.contains(KEY_ANDROID_ID + userId)) {
            return getProfile(userId);
        }

        Set<String> usedAndroidIds = new HashSet<>();
        Set<String> usedModels = new HashSet<>();
        Set<String> usedDevices = new HashSet<>();
        Set<String> usedSerials = new HashSet<>();
        collectStoredValues(preferences, KEY_ANDROID_ID, usedAndroidIds);
        collectStoredValues(preferences, KEY_MODEL, usedModels);
        collectStoredValues(preferences, KEY_DEVICE, usedDevices);
        collectStoredValues(preferences, KEY_SERIAL, usedSerials);
        for (BUserInfo user : BlackBoxCore.get().getUsers()) {
            if (user.id == userId) {
                continue;
            }
            DeviceSpoofProfile existing = getProfile(user.id);
            usedAndroidIds.add(existing.androidId);
            usedModels.add(existing.model);
            usedDevices.add(existing.device);
            usedSerials.add(existing.serial);
        }

        ArrayList<DevicePreset> availablePresets = new ArrayList<>();
        Collections.addAll(availablePresets, PRESETS);
        Collections.shuffle(availablePresets, RANDOM);
        DevicePreset selected = null;
        for (DevicePreset preset : availablePresets) {
            if (!usedModels.contains(preset.model) && !usedDevices.contains(preset.device)) {
                selected = preset;
                break;
            }
        }
        if (selected == null) {
            DevicePreset fallback = PRESETS[userId % PRESETS.length];
            selected = new DevicePreset(
                    fallback.manufacturer,
                    fallback.brand,
                    fallback.model + " (Virtual " + (userId + 1) + ")",
                    fallback.device + "v" + userId,
                    fallback.product + "v" + userId,
                    fallback.board,
                    fallback.androidVersion,
                    fallback.buildId,
                    fallback.buildNumber
            );
        }

        String androidId;
        do {
            androidId = randomHex(16, false);
        } while (usedAndroidIds.contains(androidId));
        String serial;
        do {
            serial = randomHex(12, true);
        } while (usedSerials.contains(serial));

        String fingerprint = selected.brand + "/" + selected.product + "/" + selected.device + ":"
                + selected.androidVersion + "/" + selected.buildId + "/" + selected.buildNumber
                + ":user/release-keys";
        DeviceSpoofProfile profile = new DeviceSpoofProfile(
                selected.manufacturer,
                selected.brand,
                selected.model,
                selected.device,
                selected.product,
                selected.board,
                fingerprint,
                serial,
                androidId
        );
        saveProfile(userId, profile);
        return profile;
    }

    private static void collectStoredValues(SharedPreferences preferences, String keyPrefix, Set<String> values) {
        for (Map.Entry<String, ?> entry : preferences.getAll().entrySet()) {
            if (entry.getKey().startsWith(keyPrefix) && entry.getValue() instanceof String) {
                values.add((String) entry.getValue());
            }
        }
    }

    private static String randomHex(int length, boolean uppercase) {
        byte[] bytes = new byte[(length + 1) / 2];
        RANDOM.nextBytes(bytes);
        StringBuilder value = new StringBuilder(length);
        for (byte item : bytes) {
            value.append(String.format(Locale.US, "%02x", item & 0xff));
        }
        String result = value.substring(0, length);
        return uppercase ? result.toUpperCase(Locale.US) : result;
    }

    private static void saveProfile(int userId, DeviceSpoofProfile profile) {
        boolean saved = prefs().edit()
                .putString(KEY_MANUFACTURER + userId, profile.manufacturer)
                .putString(KEY_BRAND + userId, profile.brand)
                .putString(KEY_MODEL + userId, profile.model)
                .putString(KEY_DEVICE + userId, profile.device)
                .putString(KEY_PRODUCT + userId, profile.product)
                .putString(KEY_BOARD + userId, profile.board)
                .putString(KEY_FINGERPRINT + userId, profile.fingerprint)
                .putString(KEY_SERIAL + userId, profile.serial)
                .putString(KEY_ANDROID_ID + userId, profile.androidId)
                .commit();
        if (!saved) {
            throw new IllegalStateException("Could not save device spoof profile for user " + userId);
        }
    }

    public static void resetToDefaults(int userId) {
        prefs().edit()
                .remove(KEY_MANUFACTURER + userId)
                .remove(KEY_BRAND + userId)
                .remove(KEY_MODEL + userId)
                .remove(KEY_DEVICE + userId)
                .remove(KEY_PRODUCT + userId)
                .remove(KEY_BOARD + userId)
                .remove(KEY_FINGERPRINT + userId)
                .remove(KEY_SERIAL + userId)
                .remove(KEY_ANDROID_ID + userId)
                .commit();
    }

    public static void applyToCurrentProcess(int userId) {
        try {
            DeviceSpoofProfile profile = getProfile(userId);
            DeviceBuildSpoofer.apply(profile);
            NativeCore.setDeviceSpoof(
                    profile.manufacturer,
                    profile.brand,
                    profile.model,
                    profile.device,
                    profile.product,
                    profile.board,
                    profile.fingerprint,
                    profile.serial
            );
            Slog.d(TAG, "Applied device spoof for user " + userId + ": " + profile.manufacturer + " " + profile.model);
        } catch (Throwable e) {
            Slog.w(TAG, "Failed to apply device spoof for user " + userId + ": " + e.getMessage());
        }
    }

    public static String getAndroidIdForCurrentUser() {
        int userId;
        try {
            userId = BActivityThread.getUserId();
        } catch (Throwable e) {
            userId = 0;
        }
        return getProfile(userId).androidId;
    }

    public static boolean isValidAndroidId(String value) {
        return !TextUtils.isEmpty(value) && value.matches("(?i)[0-9a-f]{16}");
    }

    private static DeviceSpoofProfile buildCustomProfile(int userId, String manufacturer, String model, String androidId) {
        String safeManufacturer = normalizeManufacturer(manufacturer);
        String safeBrand = normalizeBrand(safeManufacturer);
        String safeModel = normalizeModel(model);
        String safeDevice = slugify(safeModel);
        String safeProduct = safeDevice;
        String safeBoard = safeDevice;
        String safeFingerprint = safeBrand + "/" + safeProduct + "/" + safeDevice + ":16/BBX1.260329.001/BBB001:user/release-keys";
        String safeSerial = stableSerial(safeManufacturer + "_" + safeModel + "_" + userId);
        String safeAndroidId = normalizeAndroidId(androidId, "bbb_custom_" + userId + "_" + safeDevice);
        return new DeviceSpoofProfile(
                safeManufacturer,
                safeBrand,
                safeModel,
                safeDevice,
                safeProduct,
                safeBoard,
                safeFingerprint,
                safeSerial,
                safeAndroidId
        );
    }

    private static String normalizeManufacturer(String manufacturer) {
        if (TextUtils.isEmpty(manufacturer)) {
            return "Google";
        }
        String trimmed = manufacturer.trim();
        if (trimmed.length() == 1) {
            return trimmed.toUpperCase(Locale.US);
        }
        return trimmed.substring(0, 1).toUpperCase(Locale.US) + trimmed.substring(1);
    }

    private static String normalizeBrand(String manufacturer) {
        return slugify(manufacturer);
    }

    private static String normalizeModel(String model) {
        if (TextUtils.isEmpty(model)) {
            return "Pixel 6";
        }
        return model.trim();
    }

    private static String normalizeAndroidId(String androidId, String seed) {
        if (!TextUtils.isEmpty(androidId)) {
            String normalized = androidId.trim().toLowerCase(Locale.US);
            if (isValidAndroidId(normalized)) {
                return normalized;
            }
        }
        return stableAndroidId(seed);
    }

    private static String stableAndroidId(String seed) {
        String hash = Md5Utils.md5(seed);
        if (TextUtils.isEmpty(hash)) {
            return "0f0f0f0f0f0f0f0f";
        }
        String normalized = hash.toLowerCase(Locale.US);
        return normalized.length() >= 16 ? normalized.substring(0, 16) : String.format(Locale.US, "%1$-16s", normalized).replace(' ', '0');
    }

    private static String stableSerial(String seed) {
        String hash = Md5Utils.md5(seed);
        if (TextUtils.isEmpty(hash)) {
            return "BBB000000000";
        }
        String normalized = hash.toUpperCase(Locale.US);
        return normalized.length() >= 12 ? normalized.substring(0, 12) : String.format(Locale.US, "%1$-12s", normalized).replace(' ', '0');
    }

    private static String valueOrDefault(String value, String fallback) {
        return TextUtils.isEmpty(value) ? fallback : value;
    }

    private static String slugify(String input) {
        if (TextUtils.isEmpty(input)) {
            return "device";
        }
        String normalized = input.toLowerCase(Locale.US).replaceAll("[^a-z0-9]+", "");
        return TextUtils.isEmpty(normalized) ? "device" : normalized;
    }

    private static final class DevicePreset {
        final String manufacturer;
        final String brand;
        final String model;
        final String device;
        final String product;
        final String board;
        final String androidVersion;
        final String buildId;
        final String buildNumber;

        DevicePreset(
                String manufacturer,
                String brand,
                String model,
                String device,
                String product,
                String board,
                String androidVersion,
                String buildId,
                String buildNumber
        ) {
            this.manufacturer = manufacturer;
            this.brand = brand;
            this.model = model;
            this.device = device;
            this.product = product;
            this.board = board;
            this.androidVersion = androidVersion;
            this.buildId = buildId;
            this.buildNumber = buildNumber;
        }
    }
}
